<div class="container">
    <div class="row">
    <img src="img/cotation.png" class="img-thumbnail" style="height:8em; width:8em;">
</div>
</div>


            <div class="form-group string optional study_roof_length "><label
                    class="string optional small" for="study_roof_length">Longeur</label>

                    <div class="input-group">
                        <input class="numeric float optional form-control" min="0" placeholder="0" type="number"
                            step="any" value="10" name="study[roof_length]" id="study_roof_length">
                            <div class="input-group-append">
    <label class="input-group-text" for="inputGroupSelect02">m</label>
  </div>

                </div>
            </div>
            <div class="form-group string optional study_roof_width "><label
                    class="string optional small" for="study_roof_width">Largeur</label>

                    <div class="input-group">
                        <input class="numeric float optional form-control" min="0" placeholder="0" type="number"
                            step="any" value="10" name="study[roof_width]" id="study_roof_width">
                         <div class="input-group-append">
    <label class="input-group-text" for="inputGroupSelect02">m</label>
  </div>

                </div>
            </div>
            <div class="form-group string optional study_roof_height "><label
                    class="string optional small" for="study_roof_height">Hauteur</label>

                    <div class="input-group">
                        <input class="numeric float optional form-control" min="0" placeholder="0" type="number"
                            step="any" value="3" name="study[roof_height]" id="study_roof_height">
                         <div class="input-group-append">
    <label class="input-group-text" for="inputGroupSelect02">m</label>
  </div>

                </div>
            </div>
