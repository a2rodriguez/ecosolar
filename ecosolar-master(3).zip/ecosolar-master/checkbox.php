<div class="container-fluid checkbox">
    <div class="col-sm">
  <div class="form-check form-check-inline">
    <div class="d-flex flex-column">
      <i id="checkbox_i" class="fas fa-check fa-3x"></i>
    <img id="acier" src="img/acier.jpg" class="img-thumbnail" style="height:8em; width:8em;">
  </br>
  <div class="d-flex justify-content-center">
    <input class="form-check-input" type="radio" name="couverture" id="inlineRadio1" value="option1">
  </div>
  <div class="d-flex justify-content-center">
    <label class="form-check-label" for="inlineRadio1"><p class="font-weight-light">Bac acier</p></label>
  </div>
  </div>
  </div>
  <div class="form-check form-check-inline">
    <div class="d-flex flex-column">
      <i id="checkbox_i1" class="fas fa-check fa-3x"></i>
    <img id="ardoise" src="img/ardoise.jpg" class="img-thumbnail" style="height:8em; width:8em;">
  </br>
    <div class="d-flex justify-content-center">
      <input class="form-check-input" type="radio" name="couverture" id="inlineRadio2" value="option2">
    </div>
    <div class="d-flex justify-content-center">
    <label class="form-check-label" for="inlineRadio2"><p class="font-weight-light">Ardoises</p></label>
  </div>
  </div>
  </div>
  <div class="form-check form-check-inline">
    <div class="d-flex flex-column">
      <i id="checkbox_i2" class="fas fa-check fa-3x"></i>
    <img id="tuile" src="img/tuile.jpg" class="img-thumbnail" style="height:8em; width:8em;">
  </br>
  <div class="d-flex justify-content-center">
    <input class="form-check-input" type="radio" name="couverture" id="inlineRadio3" value="option2">
  </div>
  <div class="d-flex justify-content-center">
    <label class="form-check-label" for="inlineRadio2"><p class="font-weight-light">Tuiles</p></label>
  </div>
  </div>
  </div>
  <div class="form-check form-check-inline">
    <div class="d-flex flex-column">
      <i id="checkbox_i3" class="fas fa-check fa-3x"></i>
    <img id="terrase" src="img/terrase.jpg" class="img-thumbnail" style="height:8em; width:8em;">
  </br>
  <div class="d-flex justify-content-center">
    <input class="form-check-input" type="radio" name="couverture" id="inlineRadio4" value="option2">
  </div>
  <div class="d-flex justify-content-center">
    <label class="form-check-label" for="inlineRadio2"><p class="font-weight-light">Toit terrase</p></label>
  </div>
  </div>
  </div>
  </div>
</div>
