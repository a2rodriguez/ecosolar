<?php
session_start();
include('connectbdd.php');
?>
<!DOCTYPE html>
<html>
<head>
<title>Ecosolar connexion</title>
<meta charset="UTF-8">
</head>
<body>
  <p>admin</p>
</body>
</html>
